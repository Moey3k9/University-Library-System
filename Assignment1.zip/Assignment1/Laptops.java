

public class Laptops {
	
	// Attributes
	private String model;
	private String colour;
	private int size;
	
	// Methods
	public void setLaptops(String model, String colour, int size){
		this.model = model;
		this.colour= colour;
		this.size = size;
		
	}
	
	public String getModel(){
		return model;
		
	}
	
	public String getColour(){
		return colour;
		

	}
	
	public int getSize(){
		return size;
		
	}
	

}

