
public class Dvds {
	
	// Attributes
	private String name;
	private String genre;
	private String ratings;
	
	// Methods
	public void setDvDs(String name, String gentre, String ratings, String genre){
		this.name = name;
		this.genre= genre;
		this.ratings= ratings;
		
	}
	
	public String getName(){
		return name;
		
	}
	
	public String getGenre(){
		return genre;
		

	}
	
	public String getRatings() {
		return ratings;
	}
	
	

}

