import java.util.Scanner;
import java.util.ArrayList;

public class MainMenu {
	
public  static Scanner in = new Scanner(System.in);
	
	public static ArrayList<Books>mybooks = new ArrayList<Books>();
	public static ArrayList<Journals>myjournals = new ArrayList<Journals>();
	public static ArrayList<Laptops>mylaptops = new ArrayList<Laptops>();
    public static ArrayList<Dvds>myDvds = new ArrayList<Dvds>();
	public static void main(String[] args) {
		
		menuSystem();
		hardvalues();
	}
	
	private static void JournalMenu() {
		int menu = 0;
		
		System.out.println("*****School journal Menu*****");
	    System.out.println("");
	    System.out.println("1. Add Journal");
	    System.out.println("2. Remove Journal");
	    System.out.println("3. List Journal");
	    System.out.println("4. Find Journal");
	    System.out.println("5. Edit Journal");
	    System.out.println("");
	    System.out.println("Enter yout choice->");
	    
	    menu = in.nextInt();
	    
	    switch(menu) {
	    case 1:
	    	createJournal();
	    	break;
	    case 2:
	    	removeJournal();
	    	break;
	    case 3:
		    listJournals();
		    break;
		case 4:
		    findJournal();
		    break;
		case 5:
	        editJournal();
	    }
	
}
	private static void editJournal() {
		// TODO Auto-generated method stub
		
	}

	private static void createJournal() {
		// Asking the user to provide the details of the journal that they want to add
		System.out.println("Title:");
		String title = in.next();
		System.out.println("Genre:");
		String genre = in.next();
		
		System.out.println("Author:");
		String author = in.next();
		System.out.println("year:");
		int year = in.nextInt();
		
		Journals newJournal = new Journals();
		
		newJournal.setJournals(title, genre, author, year);
		
		myjournals.add(newJournal);
		
		JournalMenu();						
	}
	
	private static void findJournal() {
		System.out.println("please type title:");
		String title = in.next();
		
		for(int i=0; i< myjournals.size(); i++) {
			
			if(myjournals.get(i).getTitle().equals(title)) {
				System.out.println("Title: " + myjournals.get(i).getTitle() + "\n " +
			"Genre: " + myjournals.get(i).getGenre() + "\n " +
			"Author: " + myjournals.get(i).getAuthor() + "\n " +
			"Year:" + myjournals.get(i).getYear());
				
				
			}
		}
		
		// return the user back to the journals menu 

		JournalMenu();
		
	}
	
	
	private static void hardvalues() {
		
		/*
		 * this method creates three journals and adds them to the myJournals Arraylist
		 * 
		 */
		
		// use the journal class to make three new instances of journals
		Journals journal1 = new Journals();
		Journals journal2 = new Journals();
		Journals journal3 = new Journals();
		
		// set the values for those three journals
		journal1.setJournals("The diary of a young girl", "Autobiography", "Anne Frank", 1989);
		journal2.setJournals("A passidge to Africa", "History", "George Alagiah", 2001 );
		journal3.setJournals("Chinese cinderalla", "Fiction", "Adeline Yen Mah", 1999 );
		
		// add those three journals to the ArrayList called myJournals
		myjournals.add(journal1);
		myjournals.add(journal2);
		myjournals.add(journal3);
		
	}
	
	private static void listJournals() {
		for(int i = 0; i < myjournals.size(); i++) {

			System.out.println(
				        	"Title: " + myjournals.get(i).getTitle() + "\n " +
							"Genre: " + myjournals.get(i).getTitle() + "\n " +
							"Author: " + myjournals.get(i).getTitle() + "\n " +
							"Year: " + myjournals.get(i).getTitle());
			}
		JournalMenu();
		
	}
	
	private static void removeJournal() {
		
		System.out.println("Please type title:");
		String title = in.next();
		
		for(int i = 0; i < myjournals.size(); i++) {
			
			if(myjournals.get(i).getTitle().equals(title)) {
				myjournals.remove(i); // removes item from the ArrayList
				
				
			    }
			}
		// return to the Journal menu
		JournalMenu();
		
		// end remove journal
		
	
		
		
	}

	private static void menuSystem(){
		
		
			
		int menu2 = 0;
		
		System.out.println("***University library system***");
		System.out.println("");
		System.out.println("1. Books");
		System.out.println("2. Journals");
		System.out.println("3. Laptops");
		System.out.println("4. Dvds");
		System.out.println("");
		System.out.println("0. Quit");
		System.out.println("Enter your choice ->");
		
		menu2 = in.nextInt();
		

	    switch(menu2) {
	    case 1:
	    	menuSystem();
	    	break;
	    case 2:
	    	JournalMenu();
	    	break;
	    case 3:
		   menuSystem();
		    break;
		case 0:
		    System.out.println("You have chosen to quit");
		    break;
	    	}
		
							
		}



}
