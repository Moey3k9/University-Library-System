
public class Journals {
	// Attributes 
		private String title;
		private String genre;
		private String author;
		private int year;
		

		//Methods
		public void setJournals(String title, String genre, String author, int year) {
			this.title = title;
			this.genre = genre;
			this.author = author;
			this.year = year;
			
		}
		
		public String getTitle(){
			return title;
		
		}
		
		public String getGenre(){
			return genre;
			
			
		}
		
		public String getAuthor(){
			return author;
			
		}
		
		public int getYear(){
			return year; 
			
			
			
			
		}
	}


